A simple package to allow the addition of durations such as CD lengths.

(for now)

Clearly I still need to write this file... and I will. Honest.

I'll also provide some decent docs in due course. I hope.