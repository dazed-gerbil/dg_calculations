from .duration import Duration

__all__ = [
    'Duration',
]
